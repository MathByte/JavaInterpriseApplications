package com.example.prog3060gp03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prog3060Gp03ApplicationTests {

	@Test
	void contextLoads() {
	}

}

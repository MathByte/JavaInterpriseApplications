package Repository;

import Model.EmployeesEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

//@Component
@Repository
public interface EmployeeRepo extends
        CrudRepository<EmployeesEntity, Integer> {
    List<EmployeesEntity> findEmployeesEntityBySalaryBetween(BigDecimal minSalary, BigDecimal maxSalary);
    List<EmployeesEntity> findEmployeesEntityByFirstNameEndsWith(String letter);
    List<EmployeesEntity> findEmployeesEntityByDepartmentId(Integer deptId);
    List<EmployeesEntity> findEmployeesEntityByManagerId(Integer managerId);

//    @Query(value = "SELECT d.departmentId, e.salary FROM EmployeesEntity e JOIN DepartmentsEntity d ON d.departmentId = e.departmentId GROUP BY d.departmentId ORDER BY d.departmentId", nativeQuery = true)
//    List<EmployeesEntity> findEmployeesEntitiesBySalary();
}